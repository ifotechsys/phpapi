<?php
require_once("sliderresthandler.php");
		
$view = "";
if(isset($_GET["view"]))
	$view = $_GET["view"];
/*
controls the RESTful services
URL mapping
*/
switch($view){

	case "all":
		// to handle REST Url /mobile/list/
		$sliderresthandler = new sliderresthandler();
		$sliderresthandler->getAllslider();
		break;

	case "" :
		//404 - not found;
		break;
}
?>
