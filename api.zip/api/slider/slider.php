<?php
require_once("dbcontroller.php");

Class Slider {
	private $slider = array();
	/*
		you should hookup the DAO here
	*/
	public function getAllslider(){
		$query = "SELECT * FROM banner";
		$dbcontroller = new DBController();
		$this->slider = $dbcontroller->executeSelectQuery($query);
		return $this->slider;
	}	
}
?>