<?php
require_once("dbcontroller.php");

Class Category {
	private $category = array();
	/*
		you should hookup the DAO here
	*/
	public function getAllcategory(){
		$query = "SELECT * FROM category";
		$dbcontroller = new DBController();
		$this->category = $dbcontroller->executeSelectQuery($query);
		return $this->category;
	}	
}
?>