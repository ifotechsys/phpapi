<?php
require_once("categoryresthandler.php");
		
$view = "";
if(isset($_GET["view"]))
	$view = $_GET["view"];
/*
controls the RESTful services
URL mapping
*/
switch($view){

	case "all":
		// to handle REST Url /mobile/list/
		$categoryresthandler = new Categoryresthandler();
		$categoryresthandler->getAllcategory();
		break;

	case "" :
		//404 - not found;
		break;
}
?>
