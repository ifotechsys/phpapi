<?php
require_once("dbcontroller.php");

Class Serviceman {
	private $serviceman = array();
	/*
		you should hookup the DAO here
	*/
	public function getAllServiceman(){
		$query = "SELECT * FROM servman";
		$dbcontroller = new DBController();
		$this->serviceman = $dbcontroller->executeSelectQuery($query);
		return $this->serviceman;
	}	
}
?>